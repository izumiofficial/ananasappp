package com.example.digitalsoil.ethrel;

import com.example.digitalsoil.DBHelper;
import com.example.digitalsoil.DBManager;
import com.example.digitalsoil.R;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class PriceEthrel extends AppCompatActivity {

    TextView b2_11, b2_12;
    TextView b2_21, b2_22;
    TextView b2_31, b2_32;
    TextView b2_41, b2_42;
    TextView b2_51, b2_52;
    TextView b2_61, b2_62;
    TextView b2_71, b2_72;
    TextView b2_81, b2_82;
    TextView b2_91;
    TextView b2_101;

    DBManager dbManager;
    DBHelper dbHelper;
    SQLiteDatabase db;
    Cursor cursor;

    //int bud;
    double npk_15;
    double npk_17;
    double caoh22;
    double feso22;
    double znso22;
    double cuso22;
    double urea2;
    double anaa;
    double ethrel2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_price_ethrel);

        //i
        b2_11 = (TextView) findViewById(R.id.b2_11);
        b2_12 = (TextView) findViewById(R.id.b2_12);

        //ii
        b2_21 = (TextView) findViewById(R.id.b2_21);
        b2_22 = (TextView) findViewById(R.id.b2_22);

        //iii
        b2_31 = (TextView) findViewById(R.id.b2_31);
        b2_32 = (TextView) findViewById(R.id.b2_32);

        //iv
        b2_41 = (TextView) findViewById(R.id.b2_41);
        b2_42 = (TextView) findViewById(R.id.b2_42);

        //v
        b2_51 = (TextView) findViewById(R.id.b2_51);
        b2_52 = (TextView) findViewById(R.id.b2_52);

        //vi
        b2_61 = (TextView) findViewById(R.id.b2_61);
        b2_62 = (TextView) findViewById(R.id.b2_62);

        //vii
        b2_71 = (TextView) findViewById(R.id.b2_71);
        b2_72 = (TextView) findViewById(R.id.b2_72);

        //viii
        b2_81 = (TextView) findViewById(R.id.b2_81);
        b2_82 = (TextView) findViewById(R.id.b2_82);

        //ix
        b2_91 = (TextView) findViewById(R.id.b2_91);

        //x
        b2_101 = (TextView) findViewById(R.id.b2_101);

        dbManager = new DBManager(this);
        dbHelper = new DBHelper(this);
        db = dbHelper.getReadableDatabase();
        cursor = dbManager.fetch(db);

        Intent intent = getIntent();
        int bud = intent.getExtras().getInt("BUD");

        //chemicals: since chemicals have the same formula, only single calculation is needed.
        double caoh = ((bud * 100.0) / 18000) * 640;
        double feso = ((bud * 100.0) / 18000) * 21;
        double znso = ((bud * 100.0) / 18000) * 42;
        double cuso = ((bud * 100.0) / 18000) * 42;
        double urea = ((bud * 100.0) / 18000) * 640;
        double water = bud * 100 * 0.001;

        //amount
        int npk15 = (bud * 20) + (bud * 20);
        int npk17 = (bud * 20);
        double caoh2 = caoh * 2;
        double feso2 = feso * 2;
        double znso2 = znso * 2;
        double cuso2 = cuso * 2;
        double ure = urea + ((bud / 225.0) * 180);
        double ethrel = (bud / 225.0) * 80;
        double h2o = (water * 2) + ((bud / 225.0) * 18);

        npk_15 = cursor.getDouble(2);
        npk_17 = cursor.getDouble(3);
        caoh22 = cursor.getDouble(4);
        feso22 = cursor.getDouble(5);
        znso22 = cursor.getDouble(6);
        cuso22 = cursor.getDouble(7);
        urea2 = cursor.getDouble(8);
        anaa = cursor.getDouble(9);
        ethrel2 = cursor.getDouble(10);

        //price
        double price_1 = (npk15 / 1000.0) * npk_15;
        double price_2 = (npk17 / 1000.0) * npk_17;
        double price_3 = (caoh2 / 1000) * caoh22;
        double price_4 = (feso2 / 1000) * feso22;
        double price_5 = (znso2 / 1000) * znso22;
        double price_6 = (cuso2 / 1000) * cuso22;
        double price_7 = (ure / 1000) * urea2;
        double price_8 = (ethrel / 500) * ethrel2;
        double total = price_1 + price_2 + price_3 + price_4 + price_5 + price_6 + price_7 + price_8;

        //set text i
        b2_11.setText(npk15 + " gram");
        b2_12.setText("RM" + String.format("%.2f", price_1));

        //set text ii
        b2_21.setText(npk17 + " gram");
        b2_22.setText("RM" + String.format("%.2f", price_2));

        //set text iii
        b2_31.setText(String.format("%.2f", caoh2) + " gram");
        b2_32.setText("RM" + String.format("%.2f", price_3));

        //set text iv
        b2_41.setText(String.format("%.2f", feso2) + " gram");
        b2_42.setText("RM" + String.format("%.2f", price_4));

        //set text v
        b2_51.setText(String.format("%.2f", znso2) + " gram");
        b2_52.setText("RM" + String.format("%.2f", price_5));

        //set text vi
        b2_61.setText(String.format("%.2f", cuso2) + " gram");
        b2_62.setText("RM" + String.format("%.2f", price_6));

        //set text vii
        b2_71.setText(String.format("%.2f", ure) + " gram");
        b2_72.setText("RM" + String.format("%.2f", price_7));

        //set text viii
        b2_81.setText(String.format("%.2f", ethrel)+ " ml");
        b2_82.setText("RM" + String.format("%.2f", price_8));

        //set text ix
        b2_91.setText(String.format("%.2f", h2o) + " liter");

        //set text total
        b2_101.setText("RM" + String.format("%.2f", total));
    }
}