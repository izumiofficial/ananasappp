package com.example.digitalsoil.anaa;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.digitalsoil.DBHelper;
import com.example.digitalsoil.DBManager;
import com.example.digitalsoil.R;

public class PriceAnaaActivity extends AppCompatActivity {

    TextView b1_11, b1_12;
    TextView b1_21, b1_22;
    TextView b1_31, b1_32;
    TextView b1_41, b1_42;
    TextView b1_51, b1_52;
    TextView b1_61, b1_62;
    TextView b1_71, b1_72;
    TextView b1_81, b1_82;
    TextView b1_91;
    TextView b1_101;

    DBManager dbManager;
    DBHelper dbHelper;
    SQLiteDatabase db;
    Cursor cursor;

    //int bud;
    double npk_15;
    double npk_17;
    double caoh22;
    double feso22;
    double znso22;
    double cuso22;
    double urea2;
    double anaa;
    double ethrel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_price_anaa);

        //i
        b1_11 = (TextView) findViewById(R.id.b1_11);
        b1_12 = (TextView) findViewById(R.id.b1_12);

        //ii
        b1_21 = (TextView) findViewById(R.id.b1_21);
        b1_22 = (TextView) findViewById(R.id.b1_22);

        //iii
        b1_31 = (TextView) findViewById(R.id.b1_31);
        b1_32 = (TextView) findViewById(R.id.b1_32);

        //iv
        b1_41 = (TextView) findViewById(R.id.b1_41);
        b1_42 = (TextView) findViewById(R.id.b1_42);

        //v
        b1_51 = (TextView) findViewById(R.id.b1_51);
        b1_52 = (TextView) findViewById(R.id.b1_52);

        //vi
        b1_61 = (TextView) findViewById(R.id.b1_61);
        b1_62 = (TextView) findViewById(R.id.b1_62);

        //vii
        b1_71 = (TextView) findViewById(R.id.b1_71);
        b1_72 = (TextView) findViewById(R.id.b1_72);

        //viii
        b1_81 = (TextView) findViewById(R.id.b1_81);
        b1_82 = (TextView) findViewById(R.id.b1_82);

        //ix
        b1_91 = (TextView) findViewById(R.id.b1_91);

        //x
        b1_101 = (TextView) findViewById(R.id.b1_101);

        dbManager = new DBManager(this);
        dbHelper = new DBHelper(this);
        db = dbHelper.getReadableDatabase();
        cursor = dbManager.fetch(db);

        Intent intent = getIntent();
        int bud = intent.getExtras().getInt("BUD");

        //chemicals: since chemicals have the same formula, only single calculation is needed.
        double caoh = ((bud * 100.0) / 18000) * 640;
        double feso = ((bud * 100.0) / 18000) * 21;
        double znso = ((bud * 100.0) / 18000) * 42;
        double cuso = ((bud * 100.0) / 18000) * 42;
        double urea = ((bud * 100.0) / 18000) * 640;
        double water = bud * 100 * 0.001;

        //amount
        int npk15 = (bud * 20) + (bud * 20);
        int npk17 = (bud * 20);
        double caoh2 = caoh * 2;
        double feso2 = feso * 2;
        double znso2 = znso * 2;
        double cuso2 = cuso * 2;
        double h2o = water * 2;

        npk_15 = cursor.getDouble(2);
        npk_17 = cursor.getDouble(3);
        caoh22 = cursor.getDouble(4);
        feso22 = cursor.getDouble(5);
        znso22 = cursor.getDouble(6);
        cuso22 = cursor.getDouble(7);
        urea2 = cursor.getDouble(8);
        anaa = cursor.getDouble(9);
        ethrel = cursor.getDouble(10);

        //price
        double price_1 = (npk15 / 1000.0) * npk_15;
        double price_2 = (npk17 / 1000.0) * npk_17;
        double price_3 = (caoh2 / 1000) * caoh22;
        double price_4 = (feso2 / 1000) * feso22;
        double price_5 = (znso2 / 1000) * znso22;
        double price_6 = (cuso2 / 1000) * cuso22;
        double price_7 = (urea / 1000) * urea2;
        double price_8 = (bud / 1000.0) * anaa;
        double total = price_1 + price_2 + price_3 + price_4 + price_5 + price_6 + price_7 + price_8;

        //set text i
        b1_11.setText(npk15 + " gram");
        b1_12.setText("RM" + String.format("%.2f", price_1));

        //set text ii
        b1_21.setText(npk17 + " gram");
        b1_22.setText("RM" + String.format("%.2f", price_2));

        //set text iii
        b1_31.setText(String.format("%.2f", caoh2) + " gram");
        b1_32.setText("RM" + String.format("%.2f", price_3));

        //set text iv
        b1_41.setText(String.format("%.2f", feso2) + " gram");
        b1_42.setText("RM" + String.format("%.2f", price_4));

        //set text v
        b1_51.setText(String.format("%.2f", znso2) + " gram");
        b1_52.setText("RM" + String.format("%.2f", price_5));

        //set text vi
        b1_61.setText(String.format("%.2f", cuso2) + " gram");
        b1_62.setText("RM" + String.format("%.2f", price_6));

        //set text vii
        b1_71.setText(String.format("%.2f", urea) + " gram");
        b1_72.setText("RM" + String.format("%.2f", price_7));

        //set text viii
        b1_81.setText(bud + " tablet");
        b1_82.setText("RM" + String.format("%.2f", price_8));

        //set text ix
        b1_91.setText(String.format("%.2f", h2o) + " liter");

        //set text total
        b1_101.setText("RM" + String.format("%.2f", total));
    }
}