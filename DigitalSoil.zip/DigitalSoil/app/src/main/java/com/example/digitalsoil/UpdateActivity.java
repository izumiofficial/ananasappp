package com.example.digitalsoil;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ButtonBarLayout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {

    EditText sulur, npk15, npk17;
    EditText caoh, feso, znso, cuso;
    EditText urea, pill, pati;
    Button update;

    DBManager dbManager;
    DBHelper dbHelper;
    SQLiteDatabase db;
    Cursor cursor;

    int uid;
    int bud;
    String sd;
    double npk_15;
    double npk_17;
    double caoh2;
    double feso2;
    double znso2;
    double cuso2;
    double urea2;
    double anaa;
    double ethrel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        dbManager = new DBManager(this);
        dbHelper = new DBHelper(this);
        db = dbHelper.getReadableDatabase();
        cursor = dbManager.fetch(db);

        sulur = (EditText) findViewById(R.id.sulur);
        npk15 = (EditText) findViewById(R.id.npk15);
        npk17 = (EditText) findViewById(R.id.npk17);

        caoh = (EditText) findViewById(R.id.caoh);
        feso = (EditText) findViewById(R.id.feso);
        znso = (EditText) findViewById(R.id.znso);
        cuso = (EditText) findViewById(R.id.cuso);

        urea = (EditText) findViewById(R.id.urea);
        pill = (EditText) findViewById(R.id.pill);
        pati = (EditText) findViewById(R.id.pati);

        update = (Button) findViewById(R.id.update);

        uid = cursor.getInt(0);
        bud = cursor.getInt(1);
        sd = cursor.getString(2);
        npk_15 = cursor.getDouble(3);
        npk_17 = cursor.getDouble(4);
        caoh2 = cursor.getDouble(5);
        feso2 = cursor.getDouble(6);
        znso2 = cursor.getDouble(7);
        cuso2 = cursor.getDouble(8);
        urea2 = cursor.getDouble(9);
        anaa = cursor.getDouble(10);
        ethrel = cursor.getDouble(11);

        sulur.setText(bud + "");
        npk15.setText(npk_15 + "");
        npk17.setText(npk_17 + "");
        caoh.setText(caoh2 + "");
        feso.setText(feso2 + "");
        znso.setText(znso2 + "");
        cuso.setText(cuso2 + "");
        urea.setText(urea2 + "");
        pill.setText(anaa + "");
        pati.setText(ethrel + "");

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbManager.update(sulur.getText().toString(), npk15.getText().toString(), npk17.getText().toString(), caoh.getText().toString(), feso.getText().toString(),
                        znso.getText().toString(), cuso.getText().toString(), urea.getText().toString(), pill.getText().toString(), pati.getText().toString());
                Toast.makeText(getApplicationContext(), "Data dikemaskini.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}