package com.example.digitalsoil;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

import com.example.digitalsoil.ethrel.ContentEthrel;
import com.example.digitalsoil.ethrel.InfoEthrel;
import com.example.digitalsoil.ethrel.PriceEthrel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import sun.bob.mcalendarview.MCalendarView;
import sun.bob.mcalendarview.MarkStyle;
import sun.bob.mcalendarview.vo.DateData;

public class EthrelActivity extends AppCompatActivity {

    CardView info_ethrel, content_ethrel, cost_ethrel;
    DBManager dbManager;
    DBHelper dbHelper;
    SQLiteDatabase db;
    Cursor cursor;

    int bud;
    String sd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ethrel);
        getSupportActionBar().hide();

        final MCalendarView calendarView = ((MCalendarView) findViewById(R.id.calendarView));

        info_ethrel = (CardView) findViewById(R.id.info_ethrel);
        content_ethrel = (CardView) findViewById(R.id.content_ethrel);
        cost_ethrel = (CardView) findViewById(R.id.cost_ethrel);

        dbManager = new DBManager(this);
        dbHelper = new DBHelper(this);
        db = dbHelper.getReadableDatabase();
        cursor = dbManager.fetch(db);

        bud = cursor.getInt(0);
        sd = cursor.getString(1);

        //view layout for info
        info_ethrel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EthrelActivity.this, InfoEthrel.class);
                startActivity(intent);
            }
        });

        //view layout for content
        content_ethrel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EthrelActivity.this, ContentEthrel.class);
                intent.putExtra("BUD", bud);
                startActivity(intent);
            }
        });

        //view layout for cost
        cost_ethrel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EthrelActivity.this, PriceEthrel.class);
                intent.putExtra("BUD", bud);
                startActivity(intent);
            }
        });

        //calendar manipulation
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Calendar bj1 = Calendar.getInstance();
        Calendar bj2 = Calendar.getInstance();
        Calendar bj3 = Calendar.getInstance();
        Calendar bj4 = Calendar.getInstance();
        Calendar bj5 = Calendar.getInstance();
        Calendar bj6 = Calendar.getInstance();
        try {
            bj1.setTime(sdf.parse(sd));
            bj2.setTime(sdf.parse(sd));
            bj3.setTime(sdf.parse(sd));
            bj4.setTime(sdf.parse(sd));
            bj5.setTime(sdf.parse(sd));
            bj6.setTime(sdf.parse(sd));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        bj1.add(Calendar.DATE, 45);
        bj2.add(Calendar.DATE, 90);
        bj3.add(Calendar.DATE, 135);
        bj4.add(Calendar.DATE, 180);
        bj5.add(Calendar.DATE, 225);
        bj6.add(Calendar.DATE, 255);

        String baja1 = sdf1.format(bj1.getTime());
        String baja2 = sdf1.format(bj2.getTime());
        String baja3 = sdf1.format(bj3.getTime());
        String baja4 = sdf1.format(bj4.getTime());
        String baja5 = sdf1.format(bj5.getTime());
        String baja6 = sdf1.format(bj6.getTime());

        String[] item1 = baja1.split("/");
        int d1 = Integer.parseInt(item1[0]);
        int m1 = Integer.parseInt(item1[1]);
        int y1 = Integer.parseInt(item1[2]);

        String[] item2 = baja2.split("/");
        int d2 = Integer.parseInt(item2[0]);
        int m2 = Integer.parseInt(item2[1]);
        int y2 = Integer.parseInt(item2[2]);

        String[] item3 = baja3.split("/");
        int d3 = Integer.parseInt(item3[0]);
        int m3 = Integer.parseInt(item3[1]);
        int y3 = Integer.parseInt(item3[2]);

        String[] item4 = baja4.split("/");
        int d4 = Integer.parseInt(item4[0]);
        int m4 = Integer.parseInt(item4[1]);
        int y4 = Integer.parseInt(item4[2]);

        String[] item5 = baja5.split("/");
        int d5 = Integer.parseInt(item5[0]);
        int m5 = Integer.parseInt(item5[1]);
        int y5 = Integer.parseInt(item5[2]);

        String[] item6 = baja6.split("/");
        int d6 = Integer.parseInt(item6[0]);
        int m6 = Integer.parseInt(item6[1]);
        int y6 = Integer.parseInt(item6[2]);

        ArrayList<DateData> dates = new ArrayList<>();
        dates.add(new DateData(y1, m1, d1));
        dates.add(new DateData(y2, m2, d2));
        dates.add(new DateData(y3, m3, d3));
        dates.add(new DateData(y4, m4, d4));
        dates.add(new DateData(y5, m5, d5));
        dates.add(new DateData(y6, m6, d6));

        calendarView.markDate(dates.get(0).getYear(),dates.get(0).getMonth(),dates.get(0).getDay()).setMarkedStyle(MarkStyle.BACKGROUND, Color.RED);
        calendarView.markDate(dates.get(1).getYear(),dates.get(1).getMonth(),dates.get(1).getDay()).setMarkedStyle(MarkStyle.BACKGROUND, Color.CYAN);
        calendarView.markDate(dates.get(2).getYear(),dates.get(2).getMonth(),dates.get(2).getDay()).setMarkedStyle(MarkStyle.BACKGROUND, Color.BLUE);
        calendarView.markDate(dates.get(3).getYear(),dates.get(3).getMonth(),dates.get(3).getDay()).setMarkedStyle(MarkStyle.BACKGROUND, Color.GREEN);
        calendarView.markDate(dates.get(4).getYear(),dates.get(4).getMonth(),dates.get(4).getDay()).setMarkedStyle(MarkStyle.BACKGROUND, Color.MAGENTA);
        calendarView.markDate(dates.get(5).getYear(),dates.get(5).getMonth(),dates.get(5).getDay()).setMarkedStyle(MarkStyle.BACKGROUND, Color.GRAY);
//        for(int i = 0; i < dates.size(); i++) {
//            //mark multiple dates with this code.
//            calendarView.markDate(dates.get(0).getYear(),dates.get(0).getMonth(),dates.get(0).getDay()).setMarkedStyle(MarkStyle.BACKGROUND, Color.RED);
//        }
    }
}