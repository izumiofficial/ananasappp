package com.example.digitalsoil;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DBManager {
    private DBHelper dbhelper;
    private Context context;
    private SQLiteDatabase database;

    int uid = 1;
    double npk_15 = 3.80;
    double npk_17 = 3.80;
    double caoh = 1.52;
    double feso = 8.00;
    double znso = 10.00;
    double cuso = 20.00;
    double urea = 3.30;
    double pill = 0.01;
    double pati = 30.00;

    public DBManager(Context ctx) {
        context = ctx;
    }

    public DBManager open() throws SQLException {
        dbhelper = new DBHelper(context);
        database = dbhelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbhelper.close();
    }

    //insert
    public void insert(String bud, String start_date) {
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.UID, uid);
        cv.put(DBHelper.BUD, bud);
        cv.put(DBHelper.START_DATE, start_date);
        cv.put(DBHelper.NPK15, npk_15);
        cv.put(DBHelper.NPK17, npk_17);
        cv.put(DBHelper.caoh, caoh);
        cv.put(DBHelper.feso, feso);
        cv.put(DBHelper.znso, znso);
        cv.put(DBHelper.cuso, cuso);
        cv.put(DBHelper.urea, urea);
        cv.put(DBHelper.pill, pill);
        cv.put(DBHelper.pati, pati);
        database.insert(DBHelper.DATABASE_TABLE, null, cv);
    }

    //get
    public Cursor fetch(SQLiteDatabase db) {
        String [] columns = new String[] {
                DBHelper.UID, DBHelper.BUD, DBHelper.START_DATE, DBHelper.NPK15, DBHelper.NPK17, DBHelper.caoh, DBHelper.feso, DBHelper.znso, DBHelper.cuso, DBHelper.urea, DBHelper.pill, DBHelper.pati
        };

        //Cursor cursor = database.query(DBHelper.DATABASE_TABLE, columns, null, null, null, null, null);
        Cursor cursor = db.query(DBHelper.DATABASE_TABLE, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }

        return cursor;
    }

    //update
    public int update(String bud, String npk15, String npk17, String caoh, String feso, String znso, String cuso, String urea, String pill, String pati) {
        ContentValues cv = new ContentValues();
        cv.put(DBHelper.BUD, bud);
        cv.put(DBHelper.NPK15, npk15);
        cv.put(DBHelper.NPK17, npk17);
        cv.put(DBHelper.caoh, caoh);
        cv.put(DBHelper.feso, feso);
        cv.put(DBHelper.znso, znso);
        cv.put(DBHelper.cuso, cuso);
        cv.put(DBHelper.urea, urea);
        cv.put(DBHelper.pill, pill);
        cv.put(DBHelper.pati, pati);

        int ret = database.update(DBHelper.DATABASE_TABLE, cv, DBHelper.UID + "=" + uid, null);
        return ret;
    }

    public int countDB() {
        String query = "SELECT * FROM " + DBHelper.DATABASE_TABLE;
        SQLiteDatabase db = dbhelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        int count = cursor.getCount();
        cursor.close();
        return count;
    }
}
