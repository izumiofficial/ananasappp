package com.example.digitalsoil.anaa;

import com.example.digitalsoil.DBHelper;
import com.example.digitalsoil.DBManager;
import com.example.digitalsoil.R;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import java.text.DecimalFormat;

public class ContentANAA extends AppCompatActivity {

    TextView nos_sulur_a, need_a, d1a1, d1a2, d1a3, d1a4, d1a5;
    TextView nos_sulur_b, need_b;
    TextView nos_sulur_c, need_c, d1c1, d1c2, d1c3, d1c4, d1c5, d1c6;
    TextView nos_sulur_d, need_d;
    TextView nos_sulur_e, need_e;
    TextView nos_sulur_f, need_f;

    DBManager dbManager;
    DBHelper dbHelper;
    SQLiteDatabase db;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content_anaa);

        //baja 1 init
        nos_sulur_a = (TextView) findViewById(R.id.nos_sulur_a);
        need_a = (TextView) findViewById(R.id.need_a);
        d1a1 = (TextView) findViewById(R.id.d1a1);
        d1a2 = (TextView) findViewById(R.id.d1a2);
        d1a3 = (TextView) findViewById(R.id.d1a3);
        d1a4 = (TextView) findViewById(R.id.d1a4);
        d1a5 = (TextView) findViewById(R.id.d1a5);

        //baja 2 init
        nos_sulur_b = (TextView) findViewById(R.id.nos_sulur_b);
        need_b = (TextView) findViewById(R.id.need_b);

        //baja 3 init
        nos_sulur_c = (TextView) findViewById(R.id.nos_sulur_c);
        need_c = (TextView) findViewById(R.id.need_c);
        d1c1 = (TextView) findViewById(R.id.d1c1);
        d1c2 = (TextView) findViewById(R.id.d1c2);
        d1c3 = (TextView) findViewById(R.id.d1c3);
        d1c4 = (TextView) findViewById(R.id.d1c4);
        d1c5 = (TextView) findViewById(R.id.d1c5);
        d1c6 = (TextView) findViewById(R.id.d1c6);

        //baja 4 init
        nos_sulur_d = (TextView) findViewById(R.id.nos_sulur_d);
        need_d = (TextView) findViewById(R.id.need_d);

        //baja 5 init
        nos_sulur_e = (TextView) findViewById(R.id.nos_sulur_e);
        need_e = (TextView) findViewById(R.id.need_e);

        //baja 6 init
        nos_sulur_f = (TextView) findViewById(R.id.nos_sulur_f);
        need_f = (TextView) findViewById(R.id.need_f);

        Intent intent = getIntent();
        int bud = intent.getExtras().getInt("BUD");

        //formula starts here
        //for need init only
        int needA = bud * 100;
        int needB = bud * 20;
        int needC = bud * 100;
        int needD = bud * 20;
        int needE = bud * 20;
        //needF is not needed

        //chemicals: since chemicals have the same formula, only single calculation is needed.
        double caoh = ((bud * 100.0) / 18000) * 640;
        double feso = ((bud * 100.0) / 18000) * 21;
        double znso = ((bud * 100.0) / 18000) * 42;
        double cuso = ((bud * 100.0) / 18000) * 42;
        double urea = ((bud * 100.0) / 18000) * 640;
        double water = bud * 100 * 0.001;

        //set text baja 1
        nos_sulur_a.setText(bud + "");
        need_a.setText(needA + " ml");
        d1a1.setText(String.format("%.2f", caoh) + " gram");
        d1a2.setText(String.format("%.2f", feso) + " gram");
        d1a3.setText(String.format("%.2f", znso) + " gram");
        d1a4.setText(String.format("%.2f", cuso) + " gram");
        d1a5.setText(String.format("%.3f", water) + " liter");

        //set text baja 2
        nos_sulur_b.setText(bud + "");
        need_b.setText(needB + " gram");

        //set text baja 3
        nos_sulur_c.setText(bud + "");
        need_c.setText(needC + " ml");
        d1c1.setText(String.format("%.2f", caoh) + " gram");
        d1c2.setText(String.format("%.2f", feso) + " gram");
        d1c3.setText(String.format("%.2f", znso) + " gram");
        d1c4.setText(String.format("%.2f", cuso) + " gram");
        d1c5.setText(String.format("%.2f", urea) + " gram");
        d1c6.setText(String.format("%.3f", water) + " liter");

        //set text baja 4
        nos_sulur_d.setText(bud + "");
        need_d.setText(needD + " gram");

        //set text baja 5
        nos_sulur_e.setText(bud + "");
        need_e.setText(needE + " gram");

        //set text baja 6
        nos_sulur_f.setText(bud + "");
        need_f.setText(bud + " tablet");
    }
}