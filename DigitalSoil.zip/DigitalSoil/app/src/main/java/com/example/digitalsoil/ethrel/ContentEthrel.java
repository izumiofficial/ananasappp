package com.example.digitalsoil.ethrel;

import com.example.digitalsoil.R;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class ContentEthrel extends AppCompatActivity {

    TextView nos_sulur_a, need_a, d2a1, d2a2, d2a3, d2a4, d2a5;
    TextView nos_sulur_b, need_b;
    TextView nos_sulur_c, need_c, d2c1, d2c2, d2c3, d2c4, d2c5, d2c6;
    TextView nos_sulur_d, need_d;
    TextView nos_sulur_e, need_e;
    TextView nos_sulur_f, need_f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content_ethrel);

        //baja 1 init
        nos_sulur_a = (TextView) findViewById(R.id.nos_sulur_a);
        need_a = (TextView) findViewById(R.id.need_a);
        d2a1 = (TextView) findViewById(R.id.d2a1);
        d2a2 = (TextView) findViewById(R.id.d2a2);
        d2a3 = (TextView) findViewById(R.id.d2a3);
        d2a4 = (TextView) findViewById(R.id.d2a4);
        d2a5 = (TextView) findViewById(R.id.d2a5);

        //baja 2 init
        nos_sulur_b = (TextView) findViewById(R.id.nos_sulur_b);
        need_b = (TextView) findViewById(R.id.need_b);

        //baja 3 init
        nos_sulur_c = (TextView) findViewById(R.id.nos_sulur_c);
        need_c = (TextView) findViewById(R.id.need_c);
        d2c1 = (TextView) findViewById(R.id.d2c1);
        d2c2 = (TextView) findViewById(R.id.d2c2);
        d2c3 = (TextView) findViewById(R.id.d2c3);
        d2c4 = (TextView) findViewById(R.id.d2c4);
        d2c5 = (TextView) findViewById(R.id.d2c5);
        d2c6 = (TextView) findViewById(R.id.d2c6);

        //baja 4 init
        nos_sulur_d = (TextView) findViewById(R.id.nos_sulur_d);
        need_d = (TextView) findViewById(R.id.need_d);

        //baja 5 init
        nos_sulur_e = (TextView) findViewById(R.id.nos_sulur_e);
        need_e = (TextView) findViewById(R.id.need_e);

        //baja 6 init
        nos_sulur_f = (TextView) findViewById(R.id.nos_sulur_f);
        need_f = (TextView) findViewById(R.id.need_f);

        Intent intent = getIntent();
        int bud = intent.getExtras().getInt("BUD");

        //formula starts here
        //for need init only
        int needA = bud * 100;
        int needB = bud * 20;
        int needC = bud * 100;
        int needD = bud * 20;
        int needE = bud * 20;
        int needF = bud * 80;

        //chemicals: since chemicals have the same formula, only single calculation is needed.
        double caoh = ((bud * 100.0) / 18000) * 640;
        double feso = ((bud * 100.0) / 18000) * 21;
        double znso = ((bud * 100.0) / 18000) * 42;
        double cuso = ((bud * 100.0) / 18000) * 42;
        double urea = ((bud * 100.0) / 18000) * 640;
        double water = bud * 100 * 0.001;

        //set text baja 1
        nos_sulur_a.setText(bud + "");
        need_a.setText(needA + " ml");
        d2a1.setText(String.format("%.2f", caoh) + " gram");
        d2a2.setText(String.format("%.2f", feso) + " gram");
        d2a3.setText(String.format("%.2f", znso) + " gram");
        d2a4.setText(String.format("%.2f", cuso) + " gram");
        d2a5.setText(String.format("%.3f", water) + " liter");

        //set text baja 2
        nos_sulur_b.setText(bud + "");
        need_b.setText(needB + " gram");

        //set text baja 3
        nos_sulur_c.setText(bud + "");
        need_c.setText(needC + " ml");
        d2c1.setText(String.format("%.2f", caoh) + " gram");
        d2c2.setText(String.format("%.2f", feso) + " gram");
        d2c3.setText(String.format("%.2f", znso) + " gram");
        d2c4.setText(String.format("%.2f", cuso) + " gram");
        d2c5.setText(String.format("%.2f", urea) + " gram");
        d2c6.setText(String.format("%.3f", water) + " liter");

        //set text baja 4
        nos_sulur_d.setText(bud + "");
        need_d.setText(needD + " gram");

        //set text baja 5
        nos_sulur_e.setText(bud + "");
        need_e.setText(needE + " gram");

        //set text baja 6
        nos_sulur_f.setText(bud + "");
        need_f.setText(needF + " ml larutan ethrel");
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_ethrel, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.price_ethrel:
//                Intent intent = new Intent(getApplicationContext(), PriceEthrel.class);
//                startActivity(intent);
//                break;
//        }
//        return super.onOptionsItemSelected(item);
//    }
}