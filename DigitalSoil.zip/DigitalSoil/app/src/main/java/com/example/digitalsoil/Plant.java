package com.example.digitalsoil;

public class Plant {
    int bud;
    String start_date;

    public Plant() {

    }

    public Plant(int bud, String start_date) {
        this.bud = bud;
        this.start_date = start_date;
    }

    public int getBud() {
        return bud;
    }

    public void setBud(int bud) {
        this.bud = bud;
    }

    public String getStartDate() {
        return start_date;
    }

    public void setStartDate(String start_date) {
        this.start_date = start_date;
    }
}
