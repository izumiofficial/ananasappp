package com.example.digitalsoil;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class InputActivity extends AppCompatActivity {

    EditText sulur, tarikh;
    Button simpan;
    //Button dummy;
    DBManager dbManager;

    final Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);
        getSupportActionBar().hide();

        sulur = (EditText) findViewById(R.id.sulur);
        tarikh = (EditText) findViewById(R.id.tarikh);

        simpan = (Button) findViewById(R.id.simpan);
        //dummy = (Button) findViewById(R.id.dummy);

        dbManager = new DBManager(this);
        try {
            dbManager.open();
        } catch (Exception e) {
            e.printStackTrace();
        }


        simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(sulur.getText().toString()) && TextUtils.isEmpty(tarikh.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "Sila lengkapkan data.", Toast.LENGTH_SHORT).show();
                } else {
                    dbManager.insert(sulur.getText().toString(), tarikh.getText().toString());
                    Toast.makeText(getApplicationContext(), "Data disimpan.", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    finish();
                }
            }
        });

        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                calendar.set(Calendar.YEAR, year);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.DAY_OF_MONTH, day);
                updateLabel();
            }
        };

        tarikh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(InputActivity.this, date, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        //dummy
//        dummy.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                startActivity(new Intent(getApplicationContext(), MainActivity.class));
//                finish();
//            }
//        });
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void updateLabel() {
        String format = "dd/MM/YYYY";
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.UK);

            tarikh.setText(sdf.format(calendar.getTime()));
        }
    }

    //if there is an existing data, this layout is not be shown
    @Override
    protected void onStart() {
        super.onStart();
        int count = dbManager.countDB();
        if (count != 0) {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
        }
    }
}