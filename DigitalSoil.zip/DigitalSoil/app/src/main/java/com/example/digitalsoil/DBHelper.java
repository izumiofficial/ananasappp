package com.example.digitalsoil;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    static final String DATABASE_NAME = "PLANTING.DB";
    static final int DATABASE_VERSION = 1;

    static final String DATABASE_TABLE = "PLANTS";
    static final String UID = "UID";
    static final String BUD = "BUD";
    static final String START_DATE = "START_DATE";
    static final String NPK15 = "NPK15";
    static final String NPK17 = "NPK17";
    static final String caoh = "caoh";
    static final String feso = "feso";
    static final String znso = "znso";
    static final String cuso = "cuso";
    static final String urea = "urea";
    static final String pill = "pill";
    static final String pati = "pati";

    private static final String DB_QUERY = "CREATE TABLE " + DATABASE_TABLE + " ("
            + UID + " INTEGER NOT NULL, "
            + BUD + " INTEGER NOT NULL, "
            + START_DATE + " DATE NOT NULL, "
            + NPK15 + " DOUBLE NOT NULL, "
            + NPK17 + " DOUBLE NOT NULL, "
            + caoh + " DOUBLE NOT NULL, "
            + feso + " DOUBLE NOT NULL, "
            + znso + " DOUBLE NOT NULL, "
            + cuso + " DOUBLE NOT NULL, "
            + urea + " DOUBLE NOT NULL, "
            + pill + " DOUBLE NOT NULL, "
            + pati + " DOUBLE NOT NULL);";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DB_QUERY);
    }

    //for insert data
//    public void insertData(int bud, String start_date, SQLiteDatabase db) {
//        ContentValues cv = new ContentValues();
//        cv.put();
//    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
    }
}
